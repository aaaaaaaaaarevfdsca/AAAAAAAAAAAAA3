import random
import string
import os

def generate_random_string(length=50):
    """Generates a random string of fixed length."""
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def create_obfuscation_dictionary(filename='obfuscation_dictionary.txt', target_size_mb=23):
    """Creates a file with random strings of 50 characters each until the file size reaches target_size_mb."""
    target_size_bytes = target_size_mb * 1024 * 1024  # Convert MB to bytes
    string_length = 50  # Length of each random string
    line_length = string_length + 1  # Including newline character
    buffer_size = 8192  # Size of the buffer to write at once

    with open(filename, 'w') as f:
        current_size = 0
        while current_size < target_size_bytes:
            # Generate a batch of random strings
            batch = [generate_random_string(string_length) + '\n' for _ in range(buffer_size // line_length)]
            batch_data = ''.join(batch)
            f.write(batch_data)
            current_size += len(batch_data.encode('utf-8'))
            print(f"Current file size: {current_size / (1024 * 1024):.2f} MB")

    print(f"File '{filename}' created with size {current_size / (1024 * 1024):.2f} MB")

# Run the function
create_obfuscation_dictionary()
