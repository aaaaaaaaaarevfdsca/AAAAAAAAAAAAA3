package com.spargat.blockman.layout.designs;

import android.content.Context;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.spargat.blockmanlauncher.R;

public class CustomToast {

    public static void showToast(Context context, String message, int iconResId) {
        // Creăm un LinearLayout pentru containerul toast-ului
        LinearLayout toastLayout = new LinearLayout(context);
        toastLayout.setOrientation(LinearLayout.HORIZONTAL);
        toastLayout.setPadding(16, 16, 16, 16);
        toastLayout.setBackgroundResource(R.drawable.bg_toast_black); // Setează fundalul folosind drawable

        // Creăm ImageView pentru iconiță
        ImageView toastIcon = new ImageView(context);
        toastIcon.setImageDrawable(ContextCompat.getDrawable(context, iconResId));
        toastIcon.setPadding(8, 8, 8, 8);

        // Creăm TextView pentru mesaj
        TextView toastText = new TextView(context);
        toastText.setText(message);
        toastText.setTextColor(ContextCompat.getColor(context, android.R.color.white));
        toastText.setPadding(8, 8, 8, 8);

        // Adăugăm ImageView și TextView în LinearLayout
        toastLayout.addView(toastIcon);
        toastLayout.addView(toastText);

        // Creăm și configurăm toast-ul
        Toast toast = new Toast(context);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(toastLayout);

        // Setăm poziția toast-ului la partea inferioară a ecranului
        toast.setGravity(Gravity.BOTTOM, 0, 100); // Ajustează valorile dacă este necesar

        // Afișăm toast-ul
        toast.show();
    }
}
