package com.spargat.blockman.layout;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.spargat.blockmanlauncher.R;

public class LayoutManager {

    public static void applyLayout(Activity activity, int layoutResId) {
        // Inflatează și setează layout-ul specificat pentru activitate
        LayoutInflater inflater = LayoutInflater.from(activity);
        View layoutView = inflater.inflate(layoutResId, null);

        // Setează layout-ul în activitate
        activity.setContentView(layoutView);
    }
}
