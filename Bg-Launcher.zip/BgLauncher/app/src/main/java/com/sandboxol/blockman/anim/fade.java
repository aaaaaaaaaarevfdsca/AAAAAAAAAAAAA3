package com.spargat.blockman.anim;

import android.app.Activity;

import com.spargat.blockmanlauncher.R;

public class fade {

    public static void applyTransition(Activity activity) {
        activity.overridePendingTransition(R.anim.abc_fade_in, R.anim.abc_fade_out);
    }
}
