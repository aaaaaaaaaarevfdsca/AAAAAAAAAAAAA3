package com.spargat.blockman.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.RequiresApi;

import com.spargat.blockmanlauncher.R;

public class BlockmanWebView {

    private static final String TAG = "BlockmanWebView";
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void configureWebView(Activity activity) {
        WebView myWebView = activity.findViewById(R.id.web);
        if (myWebView == null) {
            Log.e(TAG, "WebView not found in layout.");
            return;
        }
        configureWebViewSettings(myWebView, activity);
        myWebView.loadUrl("https://dfff/version?mobile=1.0.3");
    }
    @SuppressLint("SetJavaScriptEnabled")
    private static void configureWebViewSettings(WebView myWebView, Context context) {
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setSupportMultipleWindows(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        webSettings.setLoadsImagesAutomatically(true);
        myWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    view.loadUrl(url);
                    return false;
                } else {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    context.startActivity(intent);
                    return true;
                }
            }
        });
        myWebView.setWebChromeClient(new WebChromeClient());
    }
}