package com.spargat.blockman.security;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.util.Log;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class SignatureUtils {
    public static String getApkSignature(PackageManager pm, String packageName) {
        try {
            PackageInfo packageInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES);
            assert packageInfo.signatures != null;
            for (Signature signature : packageInfo.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA-1");
                md.update(signature.toByteArray());
                byte[] digest = md.digest();
                StringBuilder toRet = new StringBuilder();
                for (byte b : digest) {
                    toRet.append(String.format("%02X:", b));
                }
                if (toRet.length() > 0) {
                    toRet.setLength(toRet.length() - 1);
                }
                return toRet.toString();
            }
        } catch (PackageManager.NameNotFoundException | NoSuchAlgorithmException e) {
            Log.e("SignatureUtils", "Application crashed due to security check failure!", e);
            throw new RuntimeException("Security check failed");
        }
        return null;
    }
}
