package com.spargat.blockman.security;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Handler;
import android.util.Log;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ConnectionChecker {

    private static final long CHECK_INTERVAL = 1; // Interval de verificare de 1 milisecundă
    private static final Handler checkHandler = new Handler();
    private static final ExecutorService executorService = Executors.newSingleThreadExecutor();

    // Verifică constant conexiunea la internet, VPN și dacă se folosește o rețea proxy
    public static void startChecking(final Activity activity) {
        checkHandler.post(new Runnable() {
            @Override
            public void run() {
                executorService.execute(() -> {
                    boolean hasInternet = hasInternetConnection(activity);
                    boolean isUsingVPN = isUsingVPN(activity);
                    boolean isUsingProxy = isUsingProxy(activity);

                    if (!hasInternet || isUsingVPN || isUsingProxy) {
                        // CLOSE FORGE THE APP DOESN'T MATTER
                        crashApplication();
                    }
                });

                // Repetă verificarea la fiecare CHECK_INTERVAL milisecunde
                checkHandler.postDelayed(this, CHECK_INTERVAL);
            }
        });
    }

    // Verifică dacă există conexiune la internet
    private static boolean hasInternetConnection(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network activeNetwork = connectivityManager.getActiveNetwork();
            NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork);
            return networkCapabilities != null && (
                    networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                            networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));
        } else {
            android.net.NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
    }

    // Verifică dacă se folosește o conexiune VPN
    private static boolean isUsingVPN(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network activeNetwork = connectivityManager.getActiveNetwork();
            NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork);
            return networkCapabilities != null && networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
        } else {
            try {
                String defaultHost = android.net.Proxy.getDefaultHost();
                return defaultHost != null && !defaultHost.isEmpty();
            } catch (Exception e) {
                return false;
            }
        }
    }

    // Verifică dacă se folosește o rețea proxy
    private static boolean isUsingProxy(Context context) {
        String proxyHost;
        int proxyPort;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            proxyHost = System.getProperty("http.proxyHost");
            String portStr = System.getProperty("http.proxyPort");
            proxyPort = portStr != null ? Integer.parseInt(portStr) : -1;
        } else {
            proxyHost = android.net.Proxy.getHost(context);
            proxyPort = android.net.Proxy.getPort(context);
        }

        return proxyHost != null && !proxyHost.isEmpty() && proxyPort != -1;
    }
    private static void crashApplication() {
        Log.e("ConectionChecker", "Application crashed due to security check failure!");
        throw new RuntimeException("Security check failed");
    }
}
