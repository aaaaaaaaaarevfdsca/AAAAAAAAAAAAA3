package com.spargat.blockman.anim;

import android.app.Activity;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.spargat.blockmanlauncher.R;

public class start {

    public static void applyLogoAnimation(Activity activity) {
        ImageView propagandaIcon = activity.findViewById(R.id.Spargat);
        Animation propagandaLogoAnim = AnimationUtils.loadAnimation(activity, R.anim.logo_anim);
        propagandaIcon.startAnimation(propagandaLogoAnim);
    }
}
