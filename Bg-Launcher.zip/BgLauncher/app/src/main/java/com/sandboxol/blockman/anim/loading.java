package com.spargat.blockman.anim;

import android.app.Activity;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.spargat.blockmanlauncher.R;

public class loading {

    public static void applyLogoAnimation(Activity activity) {
        ImageView loadingIcon = activity.findViewById(R.id.loading);
        Animation loadingAnim = AnimationUtils.loadAnimation(activity, R.anim.start_loading);
        loadingIcon.startAnimation(loadingAnim);
    }
}
