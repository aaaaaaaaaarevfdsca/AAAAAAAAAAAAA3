package com.spargat.blockman.handler;

import android.os.Handler;
import android.os.Looper;
import java.util.HashMap;
import java.util.Map;

public class HandlerManager {

    private final Map<String, Handler> handlers;

    public HandlerManager() {
        handlers = new HashMap<>();
    }

    /**
     * Adaugă un handler nou la manager.
     * @param handlerName Numele handler-ului.
     * @param looper Looper-ul asociat handler-ului.
     */
    public void addHandler(String handlerName, Looper looper) {
        // Verificăm dacă handler-ul există deja pentru a evita suprascrierea
        if (handlers.containsKey(handlerName)) {
            throw new IllegalArgumentException("Handler " + handlerName + " deja existent!");
        }
        handlers.put(handlerName, new Handler(looper));
    }

    /**
     * Obține un handler după nume.
     * @param handlerName Numele handler-ului.
     * @return Handler-ul asociat numelui, sau null dacă nu există.
     */
    public Handler getHandler(String handlerName) {
        return handlers.get(handlerName);
    }

    /**
     * Postează o sarcină cu întârziere pe un anumit handler.
     * @param handlerName Numele handler-ului pe care se postează sarcina.
     * @param task Sarcina de executat.
     * @param delayMillis Întârzierea înainte de executarea sarcinii.
     */
    public void postDelayed(String handlerName, Runnable task, long delayMillis) {
        Handler handler = handlers.get(handlerName);
        if (handler != null) {
            handler.postDelayed(task, delayMillis);
        } else {
            throw new IllegalArgumentException("Handler " + handlerName + " nu există!");
        }
    }
}
