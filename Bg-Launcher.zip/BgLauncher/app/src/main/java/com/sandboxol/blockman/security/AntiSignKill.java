package com.spargat.blockman.security;

import android.content.Context;
import android.util.Log;

public class AntiSignKill {
    private static final String TARGET_CLASS_1 = "org.lsposed.hiddenapibypass.HiddenApiBypass";
    private static final String TARGET_CLASS_2 = "np.manager.KillSigner.Application77";
    private static final String TARGET_CLASS_3 = "np.App";
    private static final String TARGET_CLASS_4 = "np.manager.FuckSign";
    private static final String TARGET_CLASS_5 = "sharkfall.inc.signkiller.SignKillerApp";
    public static boolean isAnyClassPresent(Context context) {
        return isClassPresent(TARGET_CLASS_1) || isClassPresent(TARGET_CLASS_2) || isClassPresent(TARGET_CLASS_3)|| isClassPresent(TARGET_CLASS_4)|| isClassPresent(TARGET_CLASS_5);
    }
    private static boolean isClassPresent(String className) {
        try {
            Class<?> detectedClass = Class.forName(className);
            return detectedClass != null;
        } catch (ClassNotFoundException e) {
            Log.d("AntiSignKill", "Class not found: " + className);
            return false;
        }
    }
    public static void performSecurityCheck(Context context) {
        if (isAnyClassPresent(context)) {
            crashApplication();
        }
    }
    private static void crashApplication() {
        Log.e("AntiSignKill", "Application crashed due to security check failure!");
        throw new RuntimeException("Security check failed");
    }
}
