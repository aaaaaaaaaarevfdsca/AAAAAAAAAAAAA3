package com.spargat.blockman.security;

import android.content.Context;
import android.util.Log;

public class PackageUtils {

    private static final String ALLOWED_PACKAGE_1 = "com.spargat.blockmanlauncher";
    private static final String ALLOWED_PACKAGE_2 = "com.spargat.blockmanlauncher.debug";
    private static final String ALLOWED_PACKAGE_3 = "com.spargat.blockmanlauncher.vip";
    private static final String ALLOWED_PACKAGE_4 = "com.spargat.blockmanlauncher.beta";
    private static final String ALLOWED_PACKAGE_5 = "com.spargat.blockmanlauncher.dev";

    public static void check(Context context) {
        try {
            String packageName = context.getPackageName();
            if (!packageName.equals(ALLOWED_PACKAGE_1) && !packageName.equals(ALLOWED_PACKAGE_2)&& !packageName.equals(ALLOWED_PACKAGE_3)&& !packageName.equals(ALLOWED_PACKAGE_4)&& !packageName.equals(ALLOWED_PACKAGE_5)) {
                throw new SecurityException("Package name not allowed: " + packageName);
            }
            Log.d("PackageUtils", "Package name is valid: " + packageName);
        } catch (Exception e) {
            Log.e("PackageUtils", "Security check failed!", e);
            throw new RuntimeException("Security check failed", e);
        }
    }
}
