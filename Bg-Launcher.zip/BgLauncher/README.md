# 🚀 Blockman Launcher Application Project

This repository contains the mobile aplication of the Blockman Launcher project.

## Developers

- Comical(discord:comicalboss)
- AnatineSquire40(discord:anatinesquire40k)
- TheKing(discord:the_king.78)

## Compille

- Android Studio Koala 2024.2.1

## Current states

- android compile sdk 35
- android maxSdk 35
- android minSdk 21
- Java 8

## Global TODO

- patch lposted hiddenapi (semi patched)
- patch kill sign (semi patched)
- patch any way to delete ads
- encode assets
- decompille libs
- fix errors (fixed + new structure)
- add firebase
- add sign v4,v3,v2 and v1 detect